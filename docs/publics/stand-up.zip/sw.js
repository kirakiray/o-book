importScripts(`https://cdn.jsdelivr.net/npm/obook@2.1.9/src/sw/base.js`);
