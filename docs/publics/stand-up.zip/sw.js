importScripts(`https://cdn.jsdelivr.net/npm/obook@2.1.16/src/sw/base.js`);
