importScripts(`https://cdn.jsdelivr.net/npm/obook@2.1.21/src/sw/base.js`);
