importScripts(`https://cdn.jsdelivr.net/npm/obook@2.1.38/src/sw/base.js`);
