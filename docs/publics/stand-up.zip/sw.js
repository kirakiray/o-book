importScripts(`https://cdn.jsdelivr.net/npm/obook@2.1.2/src/sw/base.js`);
