importScripts(`https://cdn.jsdelivr.net/npm/obook@2.1.31/src/sw/base.js`);
