importScripts(`https://cdn.jsdelivr.net/npm/obook@2.1.4/src/sw/base.js`);
