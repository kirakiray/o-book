importScripts(`https://cdn.jsdelivr.net/npm/obook@2.1.41/src/sw/base.js`);
